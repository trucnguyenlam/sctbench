var searchData=
[
  ['category',['category',['../structxed__iform__info__s.html#abe0e7654223c86df2c33d2fec7e3b5cf',1,'xed_iform_info_s']]],
  ['cf',['cf',['../unionxed__flag__set__s.html#a651259e24a24a1f9f40e9bedac0ad560',1,'xed_flag_set_s']]],
  ['chip',['chip',['../structxed__operand__storage__s.html#a522f16922869deae0f982f6277470b14',1,'xed_operand_storage_s']]],
  ['currently_5fused_5fspace',['currently_used_space',['../structxed__immdis__s.html#aa5fa898615728484b9153ffcedcabdd3',1,'xed_immdis_s']]]
];
