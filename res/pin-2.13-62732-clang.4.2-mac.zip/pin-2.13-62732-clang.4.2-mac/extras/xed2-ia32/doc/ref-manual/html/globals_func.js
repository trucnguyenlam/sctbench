var globals_func =
[
    [ "s", "globals_func.html", null ],
    [ "x", "globals_func_0x78.html", null ]
];