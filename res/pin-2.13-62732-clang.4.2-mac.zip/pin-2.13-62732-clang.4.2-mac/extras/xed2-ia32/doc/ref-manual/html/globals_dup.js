var globals_dup =
[
    [ "s", "globals.html", null ],
    [ "x", "globals_0x78.html", null ]
];