var globals_eval =
[
    [ "x", "globals_eval.html", null ]
];